package iaragonzalezrecu1_125;

public class Carguero extends Nave {
    private int capacidadCarga;

    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println("El carguero " + nombre + " puede explorar y transporta una carga de: " + capacidadCarga + " toneladas.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Capacidad de carga: " + capacidadCarga + " toneladas";
    }
}
