package iaragonzalezrecu1_125;

import java.util.ArrayList;
import java.util.List;

public class SistemaExpediciones {
    private List<Nave> naves;

    public SistemaExpediciones() {
        naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave) {
        for (Nave n : naves) {
            if (n.nombre.equals(nave.nombre) && n.anioLanzamiento == nave.anioLanzamiento) {
                throw new NaveRepetidaException("Ya existe una nave con el nombre " + nave.nombre + " y el año de lanzamiento " + nave.anioLanzamiento);
            }
        }
        naves.add(nave);
    }

    public void mostrarNaves() {
        for (Nave nave : naves) {
            System.out.println(nave);
        }
    }

    public void iniciarExploracion() {
        for (Nave nave : naves) {
            if (nave instanceof NaveExploracion || nave instanceof Carguero) {
                nave.explorar();
            } else {
                System.out.println("El " + nave.nombre + " es un crucero estelar y no puede iniciar una misión de exploración.");
            }
        }
    }
}

