package iaragonzalezrecu1_125;

public class CruceroEstelar extends Nave {
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int cantidadPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public void explorar() {
        System.out.println("El crucero estelar " + nombre + " no puede iniciar una mision, solo es para llevar pasajeros.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Cantidad de pasajeros: " + cantidadPasajeros;
    }
}
