package iaragonzalezrecu1_125;

public class Iaragonzalezrecu1_125 {
    public static void main(String[] args) {
        SistemaExpediciones sistema = new SistemaExpediciones();

        NaveExploracion nave1 = new NaveExploracion("Exploradora X", 5, 2025, TipoMision.CARTOGRAFIA);
        Carguero carguero1 = new Carguero("Galáctica", 10, 2022, 300);
        CruceroEstelar crucero1 = new CruceroEstelar("Estrella del Sur", 20, 2023, 1000);

        try {
            sistema.agregarNave(nave1);
            sistema.agregarNave(carguero1);
            sistema.agregarNave(crucero1);

            sistema.agregarNave(new NaveExploracion("Exploradora X", 5, 2025, TipoMision.INVESTIGACION));
        } catch (NaveRepetidaException e) {
            System.out.println(e.getMessage());
        }

        sistema.mostrarNaves();
    }
}
