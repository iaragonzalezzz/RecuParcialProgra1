package iaragonzalezrecu1_125;

public abstract class Nave {
    protected String nombre;
    protected int capacidadTripulacion;
    protected int anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public abstract void explorar();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Nave nave = (Nave) obj;
        return anioLanzamiento == nave.anioLanzamiento &&
               nombre.equals(nave.nombre);
    }

    @Override
    public int hashCode() {
        int result = nombre.hashCode();
        result = 31 * result + anioLanzamiento; 
        return result;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Capacidad de tripulación: " + capacidadTripulacion + " | Año de lanzamiento: " + anioLanzamiento;
    }
}
