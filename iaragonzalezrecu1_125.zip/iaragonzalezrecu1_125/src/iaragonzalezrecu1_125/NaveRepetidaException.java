package iaragonzalezrecu1_125;

public class NaveRepetidaException extends RuntimeException {
    public NaveRepetidaException(String message) {
        super(message);
    }
}

