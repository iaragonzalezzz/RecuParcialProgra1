package iaragonzalezrecu1_125;

public class NaveExploracion extends Nave {
    private TipoMision tipoMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public void explorar() {
        System.out.println("La nave " + nombre + " esta explorando con la mision de: " + tipoMision);
    }

    @Override
    public String toString() {
        return super.toString() + " | Tipo de mision: " + tipoMision;
    }
}
