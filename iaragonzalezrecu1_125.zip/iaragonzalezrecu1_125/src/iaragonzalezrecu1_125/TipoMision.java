package iaragonzalezrecu1_125;

public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}

